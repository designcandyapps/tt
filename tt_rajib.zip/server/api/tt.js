export default defineEventHandler(async () => {
  const response = await fetch("https://api.tickettailor.com/v1/events", {
    headers: {
      Accept: "application/json",
      Authorization:
        "Basic " + Buffer.from("sk_14995_133548_95cbe0f619ded70f2d57a144acefffc5:").toString("base64"),
    },
  });

  const data = await response.json();

  return data;
});